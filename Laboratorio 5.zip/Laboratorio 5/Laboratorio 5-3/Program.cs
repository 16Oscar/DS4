﻿internal class Program
{
    private static void Main(string[] args)
    {
        String[] frutas = { "Manzana", "Plátano", "Naranja" };
        foreach (string fruta in frutas)
        {
            Console.WriteLine(fruta);
        }
    }
}