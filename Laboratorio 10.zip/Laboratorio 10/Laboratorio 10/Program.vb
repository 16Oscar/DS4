Imports System

Module Program
    Sub Main(args As String())
        Console.WriteLine("Hola")
        Console.WriteLine("Este es mi primer programa de consola en VB")
    End Sub
End Module
